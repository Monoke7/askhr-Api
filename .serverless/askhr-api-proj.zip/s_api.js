
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'monoke',
  applicationName: 'askhr-api-proj',
  appUid: 'yffmYBYtHrwlT1R5zr',
  orgUid: '3624b407-d440-4260-9111-121d9d3c1180',
  deploymentUid: '94d6cda5-6a41-4b4c-acb3-23a9d8f6fe81',
  serviceName: 'askhr-api-proj',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'askhr-api-proj-dev-api', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}